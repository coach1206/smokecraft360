---
name: Hospitality OS
colors:
  surface: '#131313'
  surface-dim: '#131313'
  surface-bright: '#393939'
  surface-container-lowest: '#0e0e0e'
  surface-container-low: '#1c1b1b'
  surface-container: '#201f1f'
  surface-container-high: '#2a2a2a'
  surface-container-highest: '#353534'
  on-surface: '#e5e2e1'
  on-surface-variant: '#d4c3b7'
  inverse-surface: '#e5e2e1'
  inverse-on-surface: '#313030'
  outline: '#9d8e83'
  outline-variant: '#50453b'
  surface-tint: '#f1bc8c'
  primary: '#f1bc8c'
  on-primary: '#492905'
  primary-container: '#8c6239'
  on-primary-container: '#ffe8d7'
  inverse-primary: '#7e562e'
  secondary: '#ffb95a'
  on-secondary: '#462a00'
  secondary-container: '#c68315'
  on-secondary-container: '#3d2400'
  tertiary: '#d8c2b9'
  on-tertiary: '#3b2d27'
  tertiary-container: '#796760'
  on-tertiary-container: '#ffe8df'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdcbf'
  primary-fixed-dim: '#f1bc8c'
  on-primary-fixed: '#2d1600'
  on-primary-fixed-variant: '#633f19'
  secondary-fixed: '#ffddb6'
  secondary-fixed-dim: '#ffb95a'
  on-secondary-fixed: '#2a1800'
  on-secondary-fixed-variant: '#643f00'
  tertiary-fixed: '#f5ded5'
  tertiary-fixed-dim: '#d8c2b9'
  on-tertiary-fixed: '#251913'
  on-tertiary-fixed-variant: '#53433d'
  background: '#131313'
  on-background: '#e5e2e1'
  surface-variant: '#353534'
typography:
  display-lg:
    fontFamily: Playfair Display
    fontSize: 64px
    fontWeight: '700'
    lineHeight: 72px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Playfair Display
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
  headline-md:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
  headline-sm:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '400'
    lineHeight: 30px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-lg:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  headline-lg-mobile:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 8px
  touch-min: 56px
  gutter-md: 24px
  margin-lg: 48px
  container-max: 1440px
---

## Brand & Style
The design system is engineered for elite hospitality environments, specifically tailored for high-end lounges, private clubs, and luxury concierge services. The brand personality is **Confident, Immersive, and Educational**, designed to evoke the feeling of a master sommelier or an expert craftsman guiding the user.

The aesthetic blends **Glassmorphism** with **Tactile** influences. It utilizes deep, "inked" backgrounds to mimic premium leather and charcoal stone, punctuated by "firelight" glows that simulate the warmth of a candle-lit lounge. The visual language balances editorial sophistication with the rugged textures of raw materials like bronze and espresso-stained wood. 

The user interface must remain highly legible in low-light environments, prioritizing high-contrast typography and large, accessible touch targets for seamless interaction on communal tablets or personal devices.

## Colors
This design system operates exclusively in a **Dark Mode** ecosystem to maintain the ambiance of luxury interior spaces.

- **Primary (Burnished Bronze):** Used for key calls-to-action, active states, and premium borders. It represents craftsmanship and heritage.
- **Secondary (Glowing Amber):** Reserved for highlights, notifications, and "firelight" accents. This color should be used sparingly to draw the eye to interactive elements or educational callouts.
- **Tertiary (Deep Espresso):** The primary surface color. It provides a warmer, more organic alternative to pure black, suggesting the richness of leather.
- **Neutral (Rich Charcoal):** The foundation layer. Used for the deepest background levels and canvas states.

All colors must meet AA contrast ratios against the charcoal background to ensure readability in dim lounge lighting.

## Typography
The typography strategy pairings high-contrast editorial elegance with utilitarian precision. 

- **Headlines:** Use **Playfair Display**. It provides a literary, authoritative voice. For larger display sizes, use negative letter-spacing to enhance the "luxury magazine" feel.
- **UI & Body:** Use **Inter**. This ensures that even at smaller sizes or in low-light settings, functional text—such as ingredient lists or navigation—remains crisp and legible. 
- **Labels:** Use Inter in All-Caps with increased letter-spacing for category headers and metadata to provide a structured, organized appearance.

For touchscreen displays, the `body-lg` (20px) is the preferred size for standard reading to prevent eye strain.

## Layout & Spacing
The design system employs a **Fixed Grid** model for tablet and desktop views to ensure cinematic framing of content. 

- **Rhythm:** An 8px base unit drives all spacing decisions.
- **Touch Targets:** A minimum interactive zone of 56px is required for all primary controls, acknowledging the large-screen touchscreen nature of the product.
- **Margins:** Generous outer margins (48px+) are used to create a sense of "whitespace as luxury," preventing the UI from feeling cluttered.
- **Gutter:** 24px gutters provide clear separation between content cards, allowing the background textures and glows to breathe between elements.

On mobile devices, the layout reflows to a single-column view with a 16px safety margin, while maintaining the 56px touch height for all buttons.

## Elevation & Depth
Depth is created through light and transparency rather than heavy shadows.

- **Surface Tiers:** The base level is **Rich Charcoal**. Secondary containers use **Deep Espresso** with a subtle 1px **Burnished Bronze** inner-stroke.
- **Glassmorphism:** Overlays and modal windows utilize a heavy backdrop-blur (20px-40px) with a 10% opacity white tint. This creates a "frosted glass" effect that allows the "firelight" glows from the background to bleed through.
- **Glows:** Use soft radial gradients of **Glowing Amber** (5-10% opacity) behind primary cards or under key images to simulate a warm, ambient light source.
- **Shadows:** If used, shadows must be ultra-diffused and tinted with the **Deep Espresso** hue, avoiding "flat" black shadows.

## Shapes
The shape language is **Soft (Level 1)**. 

- **Primary Corners:** 0.25rem (4px) corner radius. This sharp-but-softened approach maintains a disciplined, professional aesthetic that feels more "architectural" than "app-like."
- **Large Components:** Cards and modals (`rounded-lg`) use 0.5rem (8px) to provide a subtle distinction from smaller UI elements like buttons.
- **Interactive States:** Use sharp lines for borders and separators to reinforce the "Craft" aspect of the brand, avoiding overly rounded or "bubbly" shapes which can detract from the premium feel.

## Components
- **Buttons:** Primary buttons feature a subtle vertical gradient of **Burnished Bronze**. Use All-Caps Inter for button labels to heighten the formal tone.
- **Cards:** Utilize the Glassmorphism style. Backgrounds should be semi-transparent with a 1px border in a 20% opacity Bronze to define the edges against the espresso surface.
- **Inputs:** Text fields should be underlines or enclosed in a Deep Espresso well. The focus state should illuminate the bottom border with a **Glowing Amber** stroke.
- **Chips/Tags:** Used for "Educational" metadata (e.g., "Peaty," "Oak-Aged"). These should be ghost-styled with a thin Bronze border and high letter-spacing.
- **Lists:** Use generous 24px padding between list items. Use Burnished Bronze icons for bullet points or navigational chevrons.
- **Selection Controls:** Checkboxes and Radio buttons should be square (consistent with the architectural shape language) and filled with Burnished Bronze when active.
- **Specialty Component - "The Curator’s Note":** A specifically styled callout box with a Playfair Display italic font and a Glowing Amber left-border, used for educational or storytelling content.